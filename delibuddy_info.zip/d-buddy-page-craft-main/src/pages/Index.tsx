
import React from 'react';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#FFCD01] relative overflow-hidden">
      {/* Background image with higher transparency */}
      <div className="absolute inset-0 w-full h-full bg-center bg-no-repeat bg-cover opacity-20" 
           style={{ backgroundImage: 'url("/lovable-uploads/7560dff9-5483-4ada-9617-ef89b8500eee.png")' }}>
      </div>
      
      {/* Background circles */}
      <div className="absolute top-0 left-0 w-[80vw] h-[80vw] rounded-full bg-[#FFD52E] opacity-60 -translate-x-1/3 -translate-y-1/3"></div>
      <div className="absolute bottom-0 right-0 w-[60vw] h-[60vw] rounded-full bg-[#FFD52E] opacity-60 translate-x-1/3 translate-y-1/3"></div>
      
      {/* Content container */}
      <div className="relative z-10 w-full max-w-lg px-6 py-8 flex flex-col items-center">
        {/* Logo and title */}
        <div className="mb-8 flex flex-col items-center">
          <div className="bg-white p-4 rounded-2xl shadow-lg mb-4">
            <div className="w-20 h-20 bg-[#FFCD01] rounded-xl flex items-center justify-center">
              <img 
                src="/lovable-uploads/9ec8ca2b-c485-46ce-822b-e87d1dfefce8.png" 
                alt="Deli Buddy Penguin" 
                className="w-16 h-16"
              />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-[#4A4238] mb-2">딜리버디</h1>
        </div>
        
        {/* Status card */}
        <div className="bg-white w-full rounded-3xl shadow-lg p-6 mb-10">
          <div className="flex items-center justify-center mb-6">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-2 animate-pulse"></div>
            <h2 className="text-xl font-semibold text-[#4A4238]">서버 상태</h2>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-[#4A4238] mb-3">
              딜리버디 서버가 정상 작동 중입니다.
            </p>
            <p className="text-gray-500">
              본 페이지는 딜리버디 백엔드 서버 안내 페이지입니다.
            </p>
          </div>
        </div>
        
        {/* Penguin mascot */}
        <div className="absolute bottom-0 right-0 md:block hidden">
          <img 
            src="/lovable-uploads/c24b3d6e-7e61-45a2-a92f-31e1bf5b1365.png" 
            alt="Deli Buddy Penguin Mascot" 
            className="w-32 h-auto"
          />
        </div>
      </div>
      
      {/* Footer */}
      <div className="w-full py-4 text-center text-[#4A4238] text-sm absolute bottom-0">
        © 2025 딜리버디 - 모든 권리 보유
      </div>
    </div>
  );
};

export default Index;
